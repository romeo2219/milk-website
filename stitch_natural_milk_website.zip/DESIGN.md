---
name: Pure & Wholesome
colors:
  surface: '#f9f9fc'
  surface-dim: '#dadadc'
  surface-bright: '#f9f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f6'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e5'
  on-surface: '#1a1c1e'
  on-surface-variant: '#41484e'
  inverse-surface: '#2f3133'
  inverse-on-surface: '#f0f0f3'
  outline: '#71787f'
  outline-variant: '#c0c7cf'
  surface-tint: '#1c648e'
  primary: '#1c648e'
  on-primary: '#ffffff'
  primary-container: '#7cb9e8'
  on-primary-container: '#00496d'
  inverse-primary: '#90cdfd'
  secondary: '#5f5e5a'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2dc'
  on-secondary-container: '#656460'
  tertiary: '#576157'
  on-tertiary: '#ffffff'
  tertiary-container: '#abb5a9'
  on-tertiary-container: '#3e473e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cae6ff'
  primary-fixed-dim: '#90cdfd'
  on-primary-fixed: '#001e30'
  on-primary-fixed-variant: '#004b70'
  secondary-fixed: '#e5e2dc'
  secondary-fixed-dim: '#c9c6c1'
  on-secondary-fixed: '#1c1c18'
  on-secondary-fixed-variant: '#474743'
  tertiary-fixed: '#dbe5d8'
  tertiary-fixed-dim: '#bfc9bd'
  on-tertiary-fixed: '#151e16'
  on-tertiary-fixed-variant: '#404940'
  background: '#f9f9fc'
  on-background: '#1a1c1e'
  surface-variant: '#e2e2e5'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

The design system is rooted in the concepts of purity, transparency, and health. It targets a discerning, health-conscious audience that values the journey from farm to table. The emotional response is one of calm, trust, and revitalization.

The aesthetic follows a **Modern Minimalist** approach with subtle **Glassmorphic** accents. By utilizing expansive whitespace (the "milk" of the design) and soft, translucent layers, the UI mimics the clarity and freshness of a glass bottle. Every element is designed to feel "breathable" and light, avoiding heavy visual weight to maintain a premium, airy atmosphere.

## Colors

The palette is derived from the natural world and the product itself.
- **Primary (Sky Blue):** A soft, calming blue used for key actions and branding highlights, representing purity and clean water.
- **Secondary (Cream):** A warm, off-white base for surfaces to avoid the clinical feel of pure white, adding a sense of richness and dairy heritage.
- **Tertiary (Dew Green):** A very muted green used for subtle health cues and success states.
- **Neutrals:** Deep charcoals are used for text to maintain high legibility without the harshness of pure black, while varying shades of "Milk White" define layout boundaries.

## Typography

This design system employs a pairing that balances friendliness with precision. 
- **Plus Jakarta Sans** is used for headings. Its geometric but soft curves evoke a modern, welcoming personality. 
- **Manrope** is used for body copy and UI labels. Its balanced proportions and clean apertures ensure maximum readability for nutritional information and product descriptions.

Use tight tracking for display headings to create a confident, premium look, and generous line-heights for body text to maintain the "airy" feel of the brand.

## Layout & Spacing

The layout philosophy relies on a **Fluid Grid** with intentional "Safe Zones." 
- **Desktop:** A 12-column grid with generous 40px margins and 24px gutters. Content should be centered with a maximum width to prevent eye strain.
- **Mobile:** A 4-column grid with 16px margins. 
- **Vertical Rhythm:** Built on an 8px base unit. Components should use "loose" padding (e.g., 24px or 32px) to reinforce the premium, uncrowded aesthetic. Use large vertical gaps between sections (80px+) to allow the design to breathe.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Soft Ambient Shadows**. 
- **Surface Layer:** The main background uses the Secondary Cream color.
- **Elevated Layer:** Cards and containers use pure white with a very soft, diffused shadow (15% opacity, 30px blur) to appear as if they are floating gently above the base.
- **Glass Effect:** Use a background blur (12px to 20px) on navigation bars and overlay modals with a semi-transparent white tint (80% opacity). This creates a "frosted glass" look that mimics a chilled milk bottle.

## Shapes

The shape language is organic and approachable. This design system uses **Rounded** corners (Level 2) to mirror the soft silhouette of a milk bottle and the fluid nature of the product. 
- **Standard UI elements:** (Buttons, Inputs) use a 0.5rem (8px) radius.
- **Large containers:** (Cards, Images) use a 1.5rem (24px) radius to create a distinctively soft, modern frame.
- **Icons:** Should feature rounded terminals and a consistent 2px stroke weight to match the typography.

## Components

- **Buttons:** Primary buttons should be solid Sky Blue with white text, using a subtle "press" animation that reduces scale slightly. Secondary buttons use a ghost style with a thin Primary border.
- **Input Fields:** Use a Secondary Cream background with a 1px border that transitions to Primary Blue on focus. Labels should always be visible above the field for accessibility.
- **Cards:** White backgrounds, rounded-xl corners, and soft ambient shadows. Ensure images within cards also inherit the rounded corner style.
- **Chips/Badges:** Use the Tertiary Dew Green with a slightly darker green text for organic/natural certifications or health tags.
- **Progress Indicators:** Use soft, rounded bars. For "Natural Milk," these should feel liquid-like, perhaps with a subtle wave animation during loading states.